package com.example.pm01app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.pm01app.Models.Cliente;

import java.util.ArrayList;
import java.util.List;

public class ClienteAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Cliente> listaClientes;

    // Constructor
    public ClienteAdapter(Context context, ArrayList<Cliente> listaClientes) {
        this.context = context;
        this.listaClientes = listaClientes;
    }

    @Override
    public int getCount() {
        return listaClientes.size();  // Retorna la cantidad de clientes en la lista
    }

    @Override
    public Object getItem(int position) {
        return listaClientes.get(position);  // Devuelve el cliente en la posición dada
    }

    @Override
    public long getItemId(int position) {
        return position;  // Devuelve el ID de la fila (en este caso, la posición)
    }

    // Método para personalizar cada fila del ListView
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Usar un LayoutInflater para inflar el diseño de cada fila
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.item_cliente, null);  // Aquí inflamos item_cliente.xml

        // Obtener las vistas del item_cliente.xml
        ImageView ivImagen = view.findViewById(R.id.ivImagen);
        TextView tvNombre = view.findViewById(R.id.tvNombre);
        TextView tvTelefono = view.findViewById(R.id.tvTelefono);
       // TextView tvCorreo = view.findViewById(R.id.tvPais);

        // Obtener el cliente actual
        Cliente cliente = listaClientes.get(position);

        // Configurar los datos para cada fila
        tvNombre.setText(cliente.getNombre());
        tvTelefono.setText(cliente.getTelefono());
      //  tvCorreo.setText(cliente.getPais());

        // Convertir la imagen de bytes (BLOB) a Bitmap
        byte[] imageBytes = cliente.getImagen();
        if (imageBytes != null) {
            Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
            ivImagen.setImageBitmap(bitmap);  // Establecer la imagen
        } else {
            ivImagen.setImageResource(android.R.drawable.ic_menu_report_image);  // Imagen predeterminada si no hay foto
        }

        return view;  // Devolver la vista de la fila
    }
    public void actualizarLista(List<Cliente> nuevaLista) {
        this.listaClientes.clear();
        this.listaClientes.addAll(nuevaLista);
        notifyDataSetChanged();
    }

}


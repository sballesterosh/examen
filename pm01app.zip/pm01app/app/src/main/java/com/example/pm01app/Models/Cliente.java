package com.example.pm01app.Models;

public class Cliente {

    private Integer id;
    private String nombre;
    private String telefono;
    private String profesion;
    private byte[] imagen;  // Campo para la imagen en formato BLOB
    private String pais;    // Nuevo campo para el país

    public Cliente() {
    }

    public Cliente(Integer id, String nombre, String telefono, String profesion, byte[] imagen, String pais) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.profesion = profesion;
        this.imagen = imagen;
        this.pais = pais;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }
}

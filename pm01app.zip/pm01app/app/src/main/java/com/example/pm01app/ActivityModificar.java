package com.example.pm01app;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pm01app.configuracion.SQLiteConexion;
import com.example.pm01app.configuracion.Transacciones;

public class ActivityModificar extends AppCompatActivity {

    EditText etNombre, etTelefono, etProfesion;
    Button btnGuardar, btnCancelar;
    int id;
    String nombre, telefono, profesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modificar);

        // Inicializar los componentes
        etNombre = findViewById(R.id.etNombre);
        etTelefono = findViewById(R.id.etTelefono);
       // etProfesion = findViewById(R.id.etProfesion);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnCancelar = findViewById(R.id.btnCancelar);

        // Obtener los datos enviados desde la actividad anterior
        Intent intent = getIntent();
        id = intent.getIntExtra("id", -1); // Obtener el ID
        nombre = intent.getStringExtra("nombre");
        telefono = intent.getStringExtra("telefono");
        profesion = intent.getStringExtra("profesion");

        // Rellenar los campos con los datos actuales
        etNombre.setText(nombre);
        etTelefono.setText(telefono);
        //etProfesion.setText(profesion);

        // Log para verificar los datos recibidos
        Log.d("ActivityModificar", "ID recibido: " + id);
        Log.d("ActivityModificar", "Nombre recibido: " + nombre);
        Log.d("ActivityModificar", "Teléfono recibido: " + telefono);
      //  Log.d("ActivityModificar", "Profesión recibida: " + profesion);

        // Guardar los cambios
        btnGuardar.setOnClickListener(v -> guardarCambios());

        // Cancelar la edición y regresar
        btnCancelar.setOnClickListener(v -> finish());
    }

    // Método para guardar los cambios
    private void guardarCambios() {
        String nuevoNombre = etNombre.getText().toString().trim();
        String nuevoTelefono = etTelefono.getText().toString().trim();
       // String nuevaProfesion = etProfesion.getText().toString().trim();

        // Verificar si los campos no están vacíos
        if (nuevoNombre.isEmpty() || nuevoTelefono.isEmpty() ) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
        } else {
            try {
                // Crear una nueva instancia de SQLiteConexion
                SQLiteConexion conexion = new SQLiteConexion(this, Transacciones.NameDB, null, 1);
                SQLiteDatabase db = conexion.getWritableDatabase();

                // Verificar si el ID existe en la base de datos
                Cursor cursor = db.query(Transacciones.Tabla, null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
                if (cursor.getCount() > 0) {
                    // Usar ContentValues para actualizar los valores
                    ContentValues values = new ContentValues();
                    values.put(Transacciones.nombre, nuevoNombre);
                    values.put(Transacciones.telefono, nuevoTelefono);
                    //values.put(Transacciones.profesion, nuevaProfesion);

                    // Actualizar los datos en la base de datos
                    String[] args = {String.valueOf(id)}; // Usamos el id para identificar el registro a actualizar
                    int rowsAffected = db.update(Transacciones.Tabla, values, "id=?", args);

                    // Log para verificar cuántas filas fueron afectadas
                    Log.d("ActivityModificar", "Filas afectadas: " + rowsAffected);

                    if (rowsAffected > 0) {
                        Toast.makeText(this, "Contacto actualizado", Toast.LENGTH_SHORT).show();
                        setResult(RESULT_OK);  // Indica que los cambios fueron exitosos
                        finish();  // Cerrar la actividad
                    } else {
                        Toast.makeText(this, "Error al actualizar el contacto. Verifica el ID", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "El contacto no existe en la base de datos", Toast.LENGTH_SHORT).show();
                }
                cursor.close(); // Cerrar el cursor
                db.close(); // Cerrar la base de datos

            } catch (Exception e) {
                // Manejo de errores si hay algún problema con la base de datos
                Log.e("ActivityModificar", "Error al actualizar el contacto", e);
                Toast.makeText(this, "Error al actualizar el contacto", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

package com.example.pm01app;

import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;
import android.Manifest;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.pm01app.configuracion.SQLiteConexion;
import com.example.pm01app.configuracion.Transacciones;

import java.io.ByteArrayOutputStream;

public class ActivityPrincipal extends AppCompatActivity {

    private EditText edtNombres, telefono, editProfesion;
    private Button btnProcesar, btnTomarFoto, btnGaleria,btLista;
    private ImageView imageView;
    private Spinner spinnerPaises;
    private Bitmap imagenBitmap = null;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        // Inicialización de los elementos de la interfaz
        initUI();

        // Llenar el spinner con países
        loadCountries();

        // Establecer los listeners para los botones
        setButtonListeners();
    }

    // Método para inicializar la interfaz
    private void initUI() {
        edtNombres = findViewById(R.id.nombres);
        telefono = findViewById(R.id.txttelefono);
        editProfesion = findViewById(R.id.profesion);
        btnProcesar = findViewById(R.id.agregar);
        btLista = findViewById(R.id.agregar2);
        btnTomarFoto = findViewById(R.id.tomarFoto);
        btnGaleria = findViewById(R.id.btngaleria);
        imageView = findViewById(R.id.imageView2);
        spinnerPaises = findViewById(R.id.spinnerPaises);
    }

    // Método para llenar el spinner con una lista de países
    private void loadCountries() {
        String[] paises = new String[] {
                "Honduras (+504)", "Guatemala (+502)", "El Salvador (+503)", "Nicaragua (+505)", "Costa Rica (+506)", "Panamá (+507)"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, paises);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPaises.setAdapter(adapter);
    }

    // Método para configurar los eventos de los botones
    private void setButtonListeners() {
        // Procesar el cliente
        btnProcesar.setOnClickListener(v -> AddClient());

        // Tomar foto desde la cámara
        btnTomarFoto.setOnClickListener(v -> {
            if (checkCameraPermission()) {
                openCamera();
            } else {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA);
            }
        });

        // Seleccionar imagen desde la galería
        btnGaleria.setOnClickListener(v -> {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            openGalleryLauncher.launch(galleryIntent);
        });
        btLista.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ActivityList.class);
            startActivity(intent);
        });
    }

    // ActivityResultLauncher para la galería
    private final ActivityResultLauncher<Intent> openGalleryLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri selectedImageUri = result.getData().getData();
                    loadImageFromUri(selectedImageUri);
                }
            });

    // Método para cargar la imagen desde la galería con rotación vertical
    private void loadImageFromUri(Uri selectedImageUri) {
        try {
            // Obtener la imagen como Bitmap
            imagenBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);

            // Llamar al método para rotar la imagen a vertical
            imagenBitmap = rotateImage(imagenBitmap);

            // Establecer la imagen en el ImageView
            imageView.setImageBitmap(imagenBitmap);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al cargar la imagen", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para rotar la imagen a 90 grados (vertical)
    private Bitmap rotateImage(Bitmap source) {
        // Crear una nueva matriz para rotar la imagen
        Matrix matrix = new Matrix();
        matrix.postRotate(90);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }

    // Verificar si el permiso de la cámara está concedido
    private boolean checkCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    // ActivityResultLauncher para permisos de cámara
    private final ActivityResultLauncher<String> requestCameraPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    openCamera();
                } else {
                    Toast.makeText(this, "Permiso denegado para usar la cámara", Toast.LENGTH_SHORT).show();
                }
            });

    // Abrir la cámara
    private void openCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.TITLE, "new_picture");
            values.put(MediaStore.Images.Media.DESCRIPTION, "Imagen capturada por la cámara");
            imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
            openCameraLauncher.launch(cameraIntent);
        } else {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            openCameraLauncher.launch(cameraIntent);
        }
    }

    // ActivityResultLauncher para la cámara
    private final ActivityResultLauncher<Intent> openCameraLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK) {
                    if (imageUri != null) {
                        loadImageFromUri(imageUri); // Usamos el mismo método de carga y rotación
                    }
                }
            });

    // Método para agregar el cliente a la base de datos
    private void AddClient() {
        if (!validateFields()) {
            return;
        }

        // Si no hay foto, mostrar un mensaje
        if (imageView.getDrawable() == null) {
            Toast.makeText(this, "Debe tomar una foto", Toast.LENGTH_SHORT).show();
            return;
        }

        // Convertir la imagen a bytes (BLOB)
        Bitmap photoBitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        byte[] imageBytes = convertImageToByteArray(photoBitmap);

        // Obtener el país seleccionado
        String paisSeleccionado = spinnerPaises.getSelectedItem().toString();

        // Registrar en la base de datos
        registerClientInDatabase(imageBytes, paisSeleccionado);
    }

    // Convertir la imagen a un array de bytes (BLOB)
    private byte[] convertImageToByteArray(Bitmap photoBitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        photoBitmap.compress(Bitmap.CompressFormat.JPEG, 70, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }

    // Registrar el cliente en la base de datos
    private void registerClientInDatabase(byte[] imageBytes, String paisSeleccionado) {
        try {
            SQLiteConexion conexion = new SQLiteConexion(this, Transacciones.NameDB, null, 1);
            SQLiteDatabase db = conexion.getWritableDatabase();

            ContentValues valores = new ContentValues();
            valores.put(Transacciones.nombre, edtNombres.getText().toString());
            valores.put(Transacciones.telefono, telefono.getText().toString());
            valores.put(Transacciones.profesion, editProfesion.getText().toString());
            valores.put(Transacciones.imagen, imageBytes);
            valores.put(Transacciones.pais, paisSeleccionado); // Guardar el país

            Long result = db.insert(Transacciones.Tabla, null, valores);
            db.close();

            // Mostrar el resultado
            if (result != -1) {
                Toast.makeText(this, "Cliente registrado correctamente", Toast.LENGTH_LONG).show();
                clearFields();
            } else {
                Toast.makeText(this, "Error al registrar el cliente", Toast.LENGTH_LONG).show();
            }
        } catch (Exception ex) {
            Log.e("Error al registrar cliente", "Mensaje: " + ex.getMessage(), ex);
            Toast.makeText(this, "No se pudo registrar el cliente", Toast.LENGTH_LONG).show();
        }
    }

    // Validar campos obligatorios
    private boolean validateFields() {
        if (edtNombres.getText().toString().isEmpty()) {
            edtNombres.setError("El nombre es obligatorio");
            return false;
        }
        if (telefono.getText().toString().isEmpty()) {
            telefono.setError("El numero es obligatorio");
            return false;
        }
        if (editProfesion.getText().toString().isEmpty()) {
            editProfesion.setError("La Nota es Obligatorio");
            return false;
        }
        return true;
    }

    // Limpiar los campos después de registrar el cliente
    private void clearFields() {
        edtNombres.setText("");
        telefono.setText("");
        editProfesion.setText("");
        imageView.setImageResource(android.R.drawable.ic_menu_camera);
        spinnerPaises.setSelection(0);
    }
}

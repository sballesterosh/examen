package com.example.pm01app;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.pm01app.Models.Cliente;
import com.example.pm01app.configuracion.SQLiteConexion;
import com.example.pm01app.configuracion.Transacciones;

import java.util.ArrayList;

public class ActivityList extends AppCompatActivity {

    SQLiteConexion conexion;
    ListView listaclientes;
    SearchView searchView;
    ArrayList<Cliente> lista;  // Lista original de clientes
    ArrayList<Cliente> listaFiltrada;  // Lista para los resultados filtrados
    ClienteAdapter adapter;
    Button btnEliminar, btnAtras, btnCompartir, btnLlamar, btnModificar, btnverimagen, btnactualizar;
    Cliente clienteSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        conexion = new SQLiteConexion(this, Transacciones.NameDB, null, 1);
        listaclientes = findViewById(R.id.listViewContactos);
        searchView = findViewById(R.id.searchView);
        btnEliminar = findViewById(R.id.btnEliminar);
        btnAtras = findViewById(R.id.btnAtras);
        btnCompartir = findViewById(R.id.btnCompartir);
        btnLlamar = findViewById(R.id.btnLlamar);
        btnModificar = findViewById(R.id.btnModificar);
        btnverimagen = findViewById(R.id.btnVerImagen);
        btnactualizar = findViewById(R.id.btnactualizar);

        // Obtener la lista de clientes desde la base de datos
        ObtenerInfo();

        // Crear un adaptador personalizado
        adapter = new ClienteAdapter(this, listaFiltrada);
        listaclientes.setAdapter(adapter);

        // Inicialmente deshabilitar los botones
        btnEliminar.setEnabled(false);
        btnLlamar.setEnabled(false);
        btnModificar.setEnabled(false);

        // Configurar el botón de eliminar
        btnEliminar.setOnClickListener(v -> eliminarCliente());

        // Configurar el botón de modificar
        btnModificar.setOnClickListener(v -> {
            if (clienteSeleccionado != null) {
                Intent intent = new Intent(ActivityList.this, ActivityModificar.class);
                intent.putExtra("id", clienteSeleccionado.getId());
                intent.putExtra("nombre", clienteSeleccionado.getNombre());
                intent.putExtra("telefono", clienteSeleccionado.getTelefono());
                startActivityForResult(intent, 1);  // Usamos startActivityForResult para obtener los resultados
            } else {
                Toast.makeText(this, "Por favor, selecciona un contacto para modificar", Toast.LENGTH_SHORT).show();
            }
        });

        // Configurar el botón de actualizar
        btnactualizar.setOnClickListener(v -> {
            ObtenerInfo();  // Obtener los datos actualizados
            actualizarListaClientes();  // Actualizar la vista
            Toast.makeText(this, "Lista actualizada", Toast.LENGTH_SHORT).show();
        });

        // Configurar el botón de ver imagen
        btnverimagen.setOnClickListener(v -> {
            if (clienteSeleccionado != null && clienteSeleccionado.getImagen() != null) {
                // Crear un ImageView para mostrar la imagen
                ImageView imageView = new ImageView(ActivityList.this);
                imageView.setImageBitmap(BitmapFactory.decodeByteArray(clienteSeleccionado.getImagen(), 0, clienteSeleccionado.getImagen().length));

                // Crear un AlertDialog para mostrar la imagen
                new AlertDialog.Builder(ActivityList.this)
                        .setTitle("Imagen del Cliente")
                        .setView(imageView)
                        .setPositiveButton("Cerrar", (dialog, which) -> dialog.dismiss())
                        .show();
            } else {
                Toast.makeText(this, "Este cliente no tiene una imagen para mostrar", Toast.LENGTH_SHORT).show();
            }
        });

        // Agregar evento de clic para seleccionar un cliente
        listaclientes.setOnItemClickListener((parent, view, position, id) -> {
            clienteSeleccionado = (Cliente) adapter.getItem(position);
            btnEliminar.setEnabled(true);
            btnLlamar.setEnabled(true);
            btnModificar.setEnabled(true);
        });

        // Configurar el botón de compartir
        btnCompartir.setOnClickListener(v -> compartirContacto());

        // Configurar el botón de llamada
        btnLlamar.setOnClickListener(v -> hacerLlamada());

        // Botón de atrás para regresar a la actividad anterior
        btnAtras.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ActivityPrincipal.class);
            startActivity(intent);
        });

        // Agregar el listener para el SearchView
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;  // No necesitas realizar ninguna acción adicional cuando se envía el texto.
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Llamar al método que filtra la lista con el nuevo texto
                filtrarClientes(newText);
                return true;
            }
        });
    }

    // Obtener los datos desde la base de datos
    private void ObtenerInfo() {
        SQLiteDatabase db = conexion.getReadableDatabase();
        Cliente client;
        lista = new ArrayList<>();
        listaFiltrada = new ArrayList<>();
        Cursor cursor = db.rawQuery(Transacciones.SelectTableClient, null);

        while (cursor.moveToNext()) {
            client = new Cliente();
            client.setId(cursor.getInt(0));
            client.setNombre(cursor.getString(1));
            client.setTelefono(cursor.getString(2));
            client.setProfesion(cursor.getString(3));
            byte[] imageBytes = cursor.getBlob(4);
            client.setImagen(imageBytes);
            lista.add(client);
        }
        cursor.close();
        listaFiltrada.addAll(lista);
    }

    // Método para notificar al adaptador que los datos han cambiado
    private void actualizarListaClientes() {
        adapter.notifyDataSetChanged();
    }

    // Método para eliminar cliente
    private void eliminarCliente() {
        if (clienteSeleccionado != null) {
            new AlertDialog.Builder(this)
                    .setTitle("Confirmar eliminación")
                    .setMessage("¿Seguro que quieres eliminar a " + clienteSeleccionado.getNombre() + "?")
                    .setPositiveButton("Sí", (dialog, which) -> {
                        SQLiteDatabase db = conexion.getWritableDatabase();
                        String[] args = {String.valueOf(clienteSeleccionado.getId())};
                        db.delete(Transacciones.Tabla, "id=?", args);
                        ObtenerInfo();  // Volver a cargar la lista actualizada
                        actualizarListaClientes();  // Actualizamos la lista en la vista
                        Toast.makeText(this, "Cliente eliminado", Toast.LENGTH_SHORT).show();
                        btnEliminar.setEnabled(false);
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();
        }
    }

    // Método para hacer una llamada
    private void hacerLlamada() {
        if (clienteSeleccionado != null) {
            String telefono = clienteSeleccionado.getTelefono();
            if (telefono != null && !telefono.isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + telefono));
                startActivity(intent);
            } else {
                Toast.makeText(this, "Este contacto no tiene número de teléfono", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Por favor, selecciona un contacto para llamar", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para compartir el contacto
    private void compartirContacto() {
        if (clienteSeleccionado != null) {
            String mensaje = "Contacto: " + clienteSeleccionado.getNombre() + " Celular:" + clienteSeleccionado.getTelefono();
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "Compartir Contacto");
            intent.putExtra(Intent.EXTRA_TEXT, mensaje);
            startActivity(Intent.createChooser(intent, "Compartir Contacto"));
        } else {
            Toast.makeText(this, "Por favor, selecciona un contacto para compartir", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para filtrar la lista de clientes
    private void filtrarClientes(String query) {
        if (query.isEmpty()) {
            listaFiltrada.clear();
            listaFiltrada.addAll(lista);  // Restauramos la lista original
        } else {
            ArrayList<Cliente> listaFiltradaTemporal = new ArrayList<>();
            for (Cliente cliente : lista) {
                if (cliente.getNombre().toLowerCase().contains(query.toLowerCase())) {
                    listaFiltradaTemporal.add(cliente);
                }
            }
            listaFiltrada.clear();
            listaFiltrada.addAll(listaFiltradaTemporal);
        }

        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            ObtenerInfo();  // Volver a cargar la lista con los cambios
            actualizarListaClientes();  // Actualizamos la vista con los datos nuevos
        }
    }
}

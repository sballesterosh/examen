package com.example.pm01app.configuracion;

public class Transacciones {

    // Nombre de la base de datos
    public static final String NameDB = "PM01DB";

    // Tabla
    public static final String Tabla = "cliente";

    // Campos
    public static final String id = "id";
    public static final String nombre = "nombres";
    public static final String telefono = "telefono";
    public static final String profesion = "profesiones";
    public static final String imagen = "imagen";  // Columna para la imagen en formato BLOB
    public static final String pais = "pais";  // Columna para almacenar el país

    // DDL Create Table
    public static final String CreateTableCliente = "CREATE TABLE " + Tabla + " (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
            "nombres TEXT, " +
            "telefono TEXT, " +
            "profesiones TEXT, " +
            "imagen BLOB, " +
            "pais TEXT)";  // Se agregó la columna para almacenar el país

    public static final String DROPTableClient = "DROP TABLE IF EXISTS " + Tabla;

    // DML
    public static final String SelectTableClient = "SELECT * FROM " + Tabla;

    // Consultas para insertar, actualizar y eliminar
    public static final String InsertCliente = "INSERT INTO " + Tabla + " (" +
            nombre + ", " +
            telefono + ", " +
            profesion + ", " +
            imagen + ", " +
            pais + ") VALUES (?, ?, ?, ?, ?)";

    public static final String UpdateCliente = "UPDATE " + Tabla + " SET " +
            nombre + " = ?, " +
            telefono + " = ?, " +
            profesion + " = ?, " +
            imagen + " = ?, " +
            pais + " = ? WHERE " + id + " = ?";

    public static final String DeleteCliente = "DELETE FROM " + Tabla + " WHERE " + id + " = ?";
}

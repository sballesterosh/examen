package com.example.pm01app;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CALL_PHONE = 1; // Código de solicitud de permiso
    private String phoneNumber = "123456789"; // Número de teléfono a llamar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Configuración de insets para EdgeToEdge
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Referencia al botón de llamada (asegúrate de que el ID coincida con tu XML)
        Button btnLlamar = findViewById(R.id.btnLlamar);

        // Configurar el evento de clic para el botón de llamada
        btnLlamar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Mostrar un AlertDialog de confirmación antes de llamar
                mostrarDialogoConfirmacion();
            }
        });
    }

    // Método para mostrar el AlertDialog de confirmación
    private void mostrarDialogoConfirmacion() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmar llamada");
        builder.setMessage("¿Deseas llamar al número " + phoneNumber + "?");
        builder.setPositiveButton(" Llamar ahora", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Verificar permisos antes de realizar la llamada
                verificarPermisos();
            }
        });
        builder.setNegativeButton("✖ Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Cerrar el diálogo sin hacer nada
                dialog.dismiss();
            }
        });
        builder.show(); // Mostrar el diálogo
    }

    // Método para verificar permisos
    private void verificarPermisos() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            // Si no tiene permiso, solicitarlo
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.CALL_PHONE}, REQUEST_CALL_PHONE);
        } else {
            // Si ya tiene permiso, realizar la llamada
            realizarLlamada();
        }
    }

    // Método para realizar la llamada
    private void realizarLlamada() {
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(intent);
    }

    // Manejar la respuesta del usuario a la solicitud de permiso
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CALL_PHONE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permiso concedido, realizar la llamada
                realizarLlamada();
            } else {
                // Permiso denegado, mostrar un mensaje al usuario
                mostrarMensajePermisoDenegado();
            }
        }
    }

    // Método para mostrar un mensaje si el permiso es denegado
    private void mostrarMensajePermisoDenegado() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permiso denegado");
        builder.setMessage("No se puede realizar la llamada porque el permiso fue denegado.");
        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.show();
    }
}
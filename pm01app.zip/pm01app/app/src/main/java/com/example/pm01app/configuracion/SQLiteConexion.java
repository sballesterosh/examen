package com.example.pm01app.configuracion;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLiteConexion extends SQLiteOpenHelper {

    public SQLiteConexion(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(Transacciones.CreateTableCliente);  // Crear la tabla inicial
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < newVersion) {
            // Si hay una actualización de versión, puedes realizar una migración adecuada.
            // Por ejemplo, si en la nueva versión tienes un cambio en la tabla, como agregar una columna.
            // En este caso, vamos a borrar la tabla antigua y crear una nueva (aunque esto elimina los datos).
            db.execSQL(Transacciones.DROPTableClient);
            onCreate(db);
        }
    }
}
